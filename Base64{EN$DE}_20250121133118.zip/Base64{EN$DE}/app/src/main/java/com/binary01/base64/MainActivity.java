package com.binary01.base64;
 
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.provider.Settings;
import android.content.Context;
import android.widget.ActionMenuView.LayoutParams;
import android.content.ClipboardManager;
import android.content.ClipData;

public class MainActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_main);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // LayoutParams Source Code For Acesss Anywhere --!
        final LinearLayout.LayoutParams paramsX= new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT,android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        paramsX.setMargins(8,8,8,8);
        final LinearLayout.LayoutParams paramsY= new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT,android.widget.LinearLayout.LayoutParams.MATCH_PARENT);
        paramsX.setMargins(8,8,8,8);
        // LayoutParams Source Code Completed ---!
        
        final ScrollView scrollView= new ScrollView(this);
        
        final LinearLayout linear1= new LinearLayout(this);
        linear1.setOrientation(1);
        linear1.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.TOP);
        linear1.setLayoutParams(paramsY);
        scrollView.addView(linear1,paramsY);
        
        final EditText editText_input= new EditText(this);
        editText_input.setHint("EnterInputText");
        editText_input.setHintTextColor(0xff6200ee);
        editText_input.setTypeface(Typeface.MONOSPACE,1);
        editText_input.setShadowLayer(3,4,3,Color.GRAY);
        linear1.addView(editText_input,paramsX);
        
        final Button encodeButton=new Button(this);
        encodeButton.setHint("ENCODE");
        encodeButton.setHintTextColor(0xff00ff00);
        encodeButton.setTypeface(Typeface.MONOSPACE,1);
        encodeButton.setShadowLayer(3,4,3,Color.GRAY);
        encodeButton.setElevation(7);
        encodeButton.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)9, 0xFFF1F1F1));
        linear1.addView(encodeButton,paramsX);
        final Button decodeButton= new Button(this);
        decodeButton.setHint("DECODE");
        decodeButton.setHintTextColor(0xffff0000);
        decodeButton.setTypeface(Typeface.MONOSPACE,1);
        decodeButton.setShadowLayer(3,4,3,Color.GRAY);
        decodeButton.setElevation(7);
        decodeButton.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)9, 0xFFF1F1F1));
        linear1.addView(decodeButton,paramsX);
        final TextView resultText= new TextView(this);
        resultText.setHint("Result");
        resultText.setHintTextColor(0xffffd700);
        resultText.setTextColor(0xffffd700);
        resultText.setTextSize(18);
        resultText.setTypeface(Typeface.MONOSPACE,1);
        resultText.setShadowLayer(3,4,3,Color.GRAY);
        linear1.addView(resultText,paramsX);
        
        final TextView hintText= new TextView(this);
        hintText.setText("-> When You Click On ResultText Get Copy To ClipBoard!");
        hintText.setTextColor(Color.GRAY);
        hintText.setTextSize(12);
        hintText.setTypeface(Typeface.MONOSPACE);
        hintText.setShadowLayer(3,4,3,Color.GRAY);
        linear1.addView(hintText,paramsX);
        // setContentView(int LayoutResId || View view, ViewGroup.LayoutPatams params);  It Directly Display on Screen ---!
        setContentView(scrollView,paramsY);

        encodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = editText_input.getText().toString();
                String encodedText = Base64.encodeToString(text.getBytes(), Base64.DEFAULT);
                resultText.setText(encodedText);
            }
        });

        decodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = editText_input.getText().toString();
                try {
                    String decodedText = new String(Base64.decode(text, Base64.DEFAULT));
                    resultText.setText(decodedText);
                } catch (Exception e) {
                    resultText.setText("Invalid Base64 text");
                }
            }
        });
        
        resultText.setOnClickListener(new OnClickListener(){
            
           @Override
           public void onClick(View v){
               
               ((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", resultText.getText().toString()));
               Toast.makeText(getApplication(), resultText.getText().toString(), Toast.LENGTH_SHORT).show();
           }
            
        });
        
        
    }
}
